##############################
### robNB v0.2 2016-10-25  ###
##############################

### Written by William H. Aeberhard
### contact: william.aeberhard@gmail.com


###########################################
### Support functions, not to be documented

link <- function(mu){log(mu)}
invlink <- function(eta){exp(eta)}
derivlink <- function(mu){1/mu}
derivinvlink <- function(eta){exp(eta)}
varfunc <- function(mu,sigma){mu+sigma*mu^2}
loglkhd <- function(sigma,y,mu){
  sum(lgamma(y+1/sigma))-length(y)*lgamma(1/sigma)-sum(lgamma(y+1))-(1/sigma)*sum(log(sigma*mu+1))+t(y)%*%log(sigma*mu/(sigma*mu+1))
}
score.sig <- function(sigma,y,mu){ # for Newton-Raphson for sigma
  sum(digamma(y+1/sigma)-digamma(1/sigma)-log(sigma*mu+1)-sigma*(y-mu)/(sigma*mu+1))
}
info.sig <- function(sigma,y,mu){ # for Newton-Raphson for sigma
  (-1/sigma^2)*(sum(trigamma(y+1/sigma))-length(y)*trigamma(1/sigma))-sum((sigma*mu^2+y)/(sigma*mu+1)^2)
}
sig.estim <- function(y,mu,sigma,minsig,maxsig,tol,maxit){
  loglkhd.sig1 <- 0
  loglkhd.sig0 <- loglkhd.sig1+tol+1
  it.sig <- 0
  while (abs(loglkhd.sig1-loglkhd.sig0)>tol & it.sig<maxit){
    loglkhd.sig0 <- loglkhd(sigma=sigma,y=y,mu=mu)
    sigma <- sigma-score.sig(sigma=sigma,y=y,mu=mu)/info.sig(sigma=sigma,y=y,mu=mu)
    if (sigma>maxsig){sigma <- maxsig}
    if (sigma<minsig){sigma <- minsig}
    loglkhd.sig1 <- loglkhd(sigma=sigma,y=y,mu=mu)
    it.sig <- it.sig+1
  }
  return(sigma)
}
Fisherinfo.sigma <- function(mui,sigma,prec){ # used stdev.nb.glm.ml and st.ml
  invsig <- 1/sigma
  jrange <- 0:qnbinom(p=prec,mu=mui,size=invsig,lower.tail=F) # 0:min(c(7000,qnbinom(p=prec,mu=mui,size=invsig,lower.tail=F)))
  pnb <- dnbinom(x=jrange,mu=mui,size=invsig)
  sigmui1 <- sigma*mui+1
  return(-sum(pnb*((digamma(jrange+invsig)-digamma(invsig)-log(sigmui1)-sigma*(jrange-mui)/sigmui1)*2/sigma^3+
                     +(trigamma(jrange+invsig)-trigamma(invsig)+sigma^2*(jrange+sigma*mui^2)/sigmui1^2)/sigma^4)))
}
tukeypsi <- function(r,c.tukey){
  ifelse(abs(r)>c.tukey,0,((r/c.tukey)^2-1)^2*r)
}
E.tukeypsi.1 <- function(mui,sigma,c.tukey){
  sqrtVmui <- sqrt(varfunc(mui,sigma))
  j1 <- max(c(ceiling(mui-c.tukey*sqrtVmui),0))
  j2 <- floor(mui+c.tukey*sqrtVmui)
  if (j1>j2){0}
  else {
    j12 <- j1:j2
    sum((((j12-mui)/(c.tukey*sqrtVmui))^2-1)^2*(j12-mui)*dnbinom(j12,mu=mui,size=1/sigma))/sqrtVmui
  }
}
E.tukeypsi.2 <- function(mui,sigma,c.tukey){
  sqrtVmui <- sqrt(varfunc(mui,sigma))
  j1 <- max(c(ceiling(mui-c.tukey*sqrtVmui),0))
  j2 <- floor(mui+c.tukey*sqrtVmui)
  if (j1>j2){0}
  else {
    j12 <- j1:j2
    sum((((j12-mui)/(c.tukey*sqrtVmui))^2-1)^2*(j12-mui)^2*dnbinom(j12,mu=mui,size=1/sigma))/sqrtVmui
  }
}
psi.sig.ML <- function(r,mu,sigma){
  digamma(r*sqrt(mu*(sigma*mu+1))+mu+1/sigma)-sigma*r*sqrt(mu/(sigma*mu+1))-digamma(1/sigma)-log(sigma*mu+1)
}
psi.sig.ML.mod <- function(j,mui,invsig){
  digamma(j+invsig)-digamma(invsig)-log(mui/invsig+1)-(j-mui)/(mui+invsig)
}
ai.sig.tukey <- function(mui,sigma,c.tukey){
  sqrtVmui <- sqrt(varfunc(mui,sigma))
  invsig <- 1/sigma
  j1 <- max(c(ceiling(mui-c.tukey*sqrtVmui),0))
  j2 <- floor(mui+c.tukey*sqrtVmui)
  if (j1>j2){0}
  else {
    j12 <- j1:j2
    sum((((j12-mui)/(c.tukey*sqrtVmui))^2-1)^2*psi.sig.ML.mod(j=j12,mui=mui,invsig=invsig)*dnbinom(x=j12,mu=mui,size=invsig))
  }
}
sig.rob.tukey <- function(sigma,y,mu,c.tukey,weights.x){
  r <- (y-mu)/sqrt(varfunc(mu,sigma))
  wi <- tukeypsi(r=r,c.tukey=c.tukey)/r
  sum((wi*psi.sig.ML(r=r,mu=mu,sigma=sigma)-sapply(X=mu,FUN=ai.sig.tukey,sigma=sigma,c.tukey=c.tukey))*weights.x)
}
fullscore.sig <- function(y,mui,sigma){ # no sum, for stdev, scores.rob, scores.rob.i and scores.mat.rob
  (digamma(y+1/sigma)-digamma(1/sigma)-log(sigma*mui+1)-sigma*(y-mui)/(sigma*mui+1))/(-sigma^2)
}
all.expectations.tukey <- function(mui,sigma,c.tukey.beta,c.tukey.sigma){
  expec <- list()
  sqrtVmui <- sqrt(varfunc(mui,sigma))
  j1.beta <- max(c(ceiling(mui-c.tukey.beta*sqrtVmui),0))
  j2.beta <- floor(mui+c.tukey.beta*sqrtVmui)
  if (j1.beta>j2.beta){
    expec$tukeypsi2 <- 0
    expec$psibetascoresig.beta <- 0
    expec$tukeypsi13 <- 0
    expec$psibetaminuspsisig <- 0
    j1.sigma <- max(c(ceiling(mui-c.tukey.sigma*sqrtVmui),0))
    j2.sigma <- floor(mui+c.tukey.sigma*sqrtVmui)
    if (j1.sigma>j2.sigma){
      expec$psibetascoresig.sigma <- 0
      expec$psiscoresig2 <- 0
      expec$psiscoresig13 <- 0
    } else {
      j12.sigma <- j1.sigma:j2.sigma
      probNB.sigma <- dnbinom(j12.sigma,mu=mui,size=1/sigma)
      resi.sigma <- (j12.sigma-mui)/sqrtVmui
      tukeyresi.sigma <- tukeypsi(r=resi.sigma,c.tukey=c.tukey.sigma)
      fullscoresig.sigma <- fullscore.sig(y=j12.sigma,mui=mui,sigma=sigma)
      ## M21, M21=t(M12) if c.tukey.beta=c.tukey.sigma
      expec$psibetascoresig.sigma <- sum(tukeyresi.sigma*fullscoresig.sigma*probNB.sigma)/sqrtVmui # varfunc^(1/2) is from the rest of M21
      ## M22
      expec$psiscoresig2 <- sum(tukeyresi.sigma/resi.sigma*fullscoresig.sigma^2*probNB.sigma)
      ## Q22
      expec$psiscoresig13 <- sum((tukeyresi.sigma/resi.sigma*fullscoresig.sigma)^2*probNB.sigma)+
        -sum(tukeyresi.sigma/resi.sigma*fullscoresig.sigma*probNB.sigma)^2
    }
  } else {
    j12.beta <- j1.beta:j2.beta
    probNB.beta <- dnbinom(j12.beta,mu=mui,size=1/sigma)
    resi.beta <- (j12.beta-mui)/sqrtVmui
    tukeyresi.beta <- tukeypsi(r=resi.beta,c.tukey=c.tukey.beta)
    fullscoresig.beta <- fullscore.sig(y=j12.beta,mui=mui,sigma=sigma)
    ## M11
    expec$tukeypsi2 <- sum(tukeyresi.beta*(j12.beta-mui)*probNB.beta)/sqrtVmui^3 # varfunc^(-3/2) is from the rest of M11
    ## M12
    expec$psibetascoresig.beta <- sum(tukeyresi.beta*fullscoresig.beta*probNB.beta)/sqrtVmui # varfunc^(1/2) is from the rest of M12
    ## Q11
    expec$tukeypsi13 <- (sum(tukeyresi.beta^2*probNB.beta)-sum(tukeyresi.beta*probNB.beta)^2)/sqrtVmui^2 # varfunc^(-1) is from the rest of Q11
    j1.sigma <- max(c(ceiling(mui-c.tukey.sigma*sqrtVmui),0))
    j2.sigma <- floor(mui+c.tukey.sigma*sqrtVmui)
    if (j1.sigma>j2.sigma){
      expec$psibetascoresig.sigma <- 0
      expec$psiscoresig2 <- 0
      expec$psibetaminuspsisig <- 0
      expec$psiscoresig13 <- 0
    } else {
      j12.sigma <- j1.sigma:j2.sigma
      probNB.sigma <- dnbinom(j12.sigma,mu=mui,size=1/sigma)
      resi.sigma <- (j12.sigma-mui)/sqrtVmui
      tukeyresi.sigma <- tukeypsi(r=resi.sigma,c.tukey=c.tukey.sigma)
      fullscoresig.sigma <- fullscore.sig(y=j12.sigma,mui=mui,sigma=sigma)
      ## M21, M21=t(M12) if c.tukey.beta=c.tukey.sigma
      expec$psibetascoresig.sigma <- sum(tukeyresi.sigma*fullscoresig.sigma*probNB.sigma)/sqrtVmui # varfunc^(1/2) is from the rest of M21
      ## M22
      expec$psiscoresig2 <- sum(tukeyresi.sigma/resi.sigma*fullscoresig.sigma^2*probNB.sigma)
      ## Q12
      if (j2.beta<j2.sigma){ # we assume j1.beta=j1.sigma=0
        expec$psibetaminuspsisig <- (sum(tukeyresi.beta*tukeyresi.sigma[1:length(j12.beta)]/
                                           resi.sigma[1:length(j12.beta)]*fullscoresig.sigma[1:length(j12.beta)]*probNB.beta)+
                                       -sum(tukeyresi.beta*probNB.beta)*sum(tukeyresi.sigma/resi.sigma*fullscoresig.sigma*probNB.sigma))/sqrtVmui # varfunc^(1/2) is from the rest of Q12
      } else {
        expec$psibetaminuspsisig <- (sum(tukeyresi.beta[1:length(j12.sigma)]*tukeyresi.sigma/resi.sigma*fullscoresig.sigma*probNB.sigma)+
                                       -sum(tukeyresi.beta*probNB.beta)*sum(tukeyresi.sigma/resi.sigma*fullscoresig.sigma*probNB.sigma))/sqrtVmui # varfunc^(1/2) is from the rest of Q12
      }
      ## Q22
      expec$psiscoresig13 <- sum((tukeyresi.sigma/resi.sigma*fullscoresig.sigma)^2*probNB.sigma)+
        -sum(tukeyresi.sigma/resi.sigma*fullscoresig.sigma*probNB.sigma)^2
    }
  }
  return(expec)
}
scores.ml <- function(theta,y,designX,offset,minmu,maxmu){ # for st.ml
  if (missing(offset)){
    mu <- invlink(designX%*%theta[-1]) # mean vector
  } else {
    mu <- invlink(designX%*%theta[-1]+offset) # mean vector
  }
  mu[which(mu>maxmu)] <- maxmu
  mu[which(mu<minmu)] <- minmu
  score.sig <- sum(digamma(y+1/theta[1])-digamma(1/theta[1])-log(theta[1]*mu+1)+
                     -theta[1]*(y-mu)/(theta[1]*mu+1))/(-theta[1]^2) # ML score for sigma
  score.bet <- t(designX)%*%as.numeric((y-mu)/(1+theta[1]*mu)) # ML scores for beta
  return(c(score.sig,score.bet)) # returns (px1) vector
}
expect.tukey.beta <- function(mui,sigma,c.tukey){
  sqrtVmui <- sqrt(varfunc(mui,sigma))
  j1 <- max(c(ceiling(mui-c.tukey*sqrtVmui),0))
  j2 <- floor(mui+c.tukey*sqrtVmui)
  if (j1>j2){
    return(0)
  } else {
    j12 <- j1:j2
    resi <- (j12-mui)/sqrtVmui
    # tukey.resi <- ifelse(abs(resi)>c.tukey,0,((resi/c.tukey)^2-1)^2*resi)
    tukey.resi <- ((resi/c.tukey)^2-1)^2*resi
    probNB <- dnbinom(j12,mu=mui,size=1/sigma)
    return(sum(tukey.resi*probNB))
  }
}
expect.tukey.sigma <- function(mui,sigma,c.tukey){
  sqrtVmui <- sqrt(varfunc(mui,sigma))
  j1 <- max(c(ceiling(mui-c.tukey*sqrtVmui),0))
  j2 <- floor(mui+c.tukey*sqrtVmui)
  j12 <- j1:j2
  if (j1>j2){
    return(0)
  } else {
    resi <- (j12-mui)/sqrtVmui
    # tukey.resi <- ifelse(abs(resi)>c.tukey,0,((resi/c.tukey)^2-1)^2)*fullscore.sig(y=j12,mui=mui,sigma=sigma)
    tukey.resi <- ((resi/c.tukey)^2-1)^2*fullscore.sig(y=j12,mui=mui,sigma=sigma)
    probNB <- dnbinom(j12,mu=mui,size=1/sigma)
    return(sum(tukey.resi*probNB))
  }
}
scores.rob <- function(theta,y,designX,offset,c.beta,c.sigma,weights.x,minmu,maxmu){
  sigma <- theta[1]
  mu <- invlink(designX%*%theta[-1]+offset) # mean vector, nothing to do with Lagrange multiplier
  mu[which(mu>maxmu)] <- maxmu
  mu[which(mu<minmu)] <- minmu
  sqrtVmu <- sqrt(varfunc(mu,sigma))
  res <- (y-mu)/sqrtVmu
  ## robust score for beta
  tukey.res.beta <- ifelse(abs(res)>c.beta,0,((res/c.beta)^2-1)^2*res)
  E.tukey.res.beta <- sapply(X=mu,FUN=expect.tukey.beta,sigma=sigma,c.tukey=c.beta)
  score.beta <- t(designX)%*%as.numeric((tukey.res.beta-E.tukey.res.beta)/sqrtVmu*mu*weights.x)
  ## robust score for sigma
  E.tukey.res.sigma <- sapply(X=mu,FUN=expect.tukey.sigma,sigma=sigma,c.tukey=c.sigma)
  score.sig.ml <- as.numeric(fullscore.sig(y=y,mui=mu,sigma=sigma)) # ML score for sigma
  score.sigma <- sum((ifelse(abs(res)>c.sigma,0,((res/c.sigma)^2-1)^2)*score.sig.ml-E.tukey.res.sigma)*weights.x)
  return(c(score.sigma,score.beta)) # returns (px1) vector (beta at end as usual)
}
scores.ml.i <- function(maxj,mui,sigma,xi){
  j.mui <- 0:maxj
  score.sig <- as.numeric(digamma(j.mui+1/sigma)-digamma(1/sigma)-log(sigma*mui+1)+
                            -sigma*(j.mui-mui)/(sigma*mui+1))/(-sigma^2) # ML score for sigma
  score.bet <- as.numeric((j.mui-mui)/(1+sigma*mui))%*%t(xi) # ML scores for beta
  return(as.matrix(cbind(score.sig,score.bet))) # (maxj+1) x p
}
maxi.lambda.ml <- function(theta1.1,theta2.1,lagrange.ini,designX,list.designX,pNB,maxj,prec,lagrange.range,offset,minmu,maxmu){ # for sdpt.ml
  mu.1 <- invlink(designX%*%c(theta1.1[-1],theta2.1)+offset)
  mu.1[which(mu.1>maxmu)] <- maxmu
  mu.1[which(mu.1<minmu)] <- minmu
  score.list <- Map(f=function(maxj,mui,xi){ # list of length=n, each is a matrix of dim=(maxj[i]+1,p)
    scores.ml.i(maxj=maxj,mui=mui,sigma=theta1.1[1],xi=xi)
  },maxj,mu.1,list.designX)
  maxi <- nlminb(start=lagrange.ini,objective=expec.cumul,gradient=gr.expec.cumul,score.list=score.list,pNB=pNB,
                 lower=lagrange.range[1],upper=lagrange.range[2])
  return(-maxi$objective)
}
maxi.lambda.rob <- function(theta1.1,theta2.1,lagrange.ini,designX,list.designX,pNB,maxj,prec,lagrange.range,c.beta,c.sigma,weights.x,offset,minmu,maxmu){ # for sdpt.rob
  mu.1 <- invlink(designX%*%c(theta1.1[-1],theta2.1)+offset)
  mu.1[which(mu.1>maxmu)] <- maxmu
  mu.1[which(mu.1<minmu)] <- minmu
  score.list <- Map(f=function(maxj,mui,xi,wi){ # list of length=n, each is a matrix of dim=(maxj[i]+1,p)
    scores.rob.i(maxj=maxj,mui=mui,sigma=theta1.1[1],xi=xi,weight.x=wi,c.beta=c.beta,c.sigma=c.sigma)
  },maxj,mu.1,list.designX,weights.x)
  maxi <- nlminb(start=lagrange.ini,objective=expec.cumul,gradient=gr.expec.cumul,score.list=score.list,pNB=pNB,
                 lower=lagrange.range[1],upper=lagrange.range[2])
  return(-maxi$objective)
}
scores.rob.i <- function(maxj,mui,sigma,xi,weight.x,c.beta,c.sigma){
  invsig <- 1/sigma
  j.mui <- 0:maxj
  sqrtVmui <- sqrt(varfunc(mui,sigma))
  res <- (j.mui-mui)/sqrtVmui
  ## robust score for beta
  tukey.res <- ifelse(abs(res)>c.beta,0,((res/c.beta)^2-1)^2*res)
  j1 <- max(c(ceiling(mui-c.beta*sqrtVmui),0))
  j2 <- floor(mui+c.beta*sqrtVmui)
  if (j1>j2){
    E.tukey.res.beta <- 0
  } else {
    j12 <- j1:j2
    resi <- (j12-mui)/sqrtVmui
    tukey.resi <- ifelse(abs(resi)>c.beta,0,((resi/c.beta)^2-1)^2*resi)
    probNB <- dnbinom(j12,mu=mui,size=invsig)
    E.tukey.res.beta <- sum(tukey.resi*probNB)
  }
  score.beta <- ((tukey.res-E.tukey.res.beta)/sqrtVmui*mui*weight.x)%*%t(xi) # length(j.mui) x length(beta)
  ## robust score for sigma
  j1 <- max(c(ceiling(mui-c.sigma*sqrtVmui),0))
  j2 <- floor(mui+c.sigma*sqrtVmui)
  if (j1>j2){
    E.tukey.res.sigma <- 0
  } else {
    j12 <- j1:j2
    resi <- (j12-mui)/sqrtVmui
    tukey.resi <- ifelse(abs(resi)>c.sigma,0,((resi/c.sigma)^2-1)^2)*fullscore.sig(y=j12,mui=mui,sigma=sigma)
    probNB <- dnbinom(j12,mu=mui,size=invsig)
    E.tukey.res.sigma <- sum(tukey.resi*probNB)
  }
  score.sig.ml <- fullscore.sig(y=j.mui,mui=mui,sigma=sigma) # length(j.mui)
  score.sigma <- (ifelse(abs(res)>c.sigma,0,((res/c.sigma)^2-1)^2)*score.sig.ml-E.tukey.res.sigma)*weight.x
  return(cbind(score.sigma,score.beta)) # returns psimat length(j.mui) x length(theta)
}
expec.cumul <- function(lambda,score.list,pNB){ # for sdpt.ml and sdpt.rob
  E.negkumul <- sum(mapply(FUN=function(pnb,score){log(crossprod(pnb,exp(score%*%lambda)))},pnb=pNB,score=score.list))
  return(as.numeric(E.negkumul)/length(score.list))
}
gr.expec.cumul <- function(lambda,score.list,pNB){ # for sdpt.ml and sdpt.rob
  g.E.negkumul <- rowSums(mapply(FUN=function(pnb,score){
    crossprod(score,as.numeric(pnb*exp(score%*%lambda)))/as.numeric(crossprod(pnb,exp(score%*%lambda)))
  },pnb=pNB,score=score.list))
  return(as.numeric(g.E.negkumul)/length(score.list))
}
negkumul.step1 <- function(lambda0,psimat){ # (-1)*emp. cumul. gen. function of psi
  #   -log(mean(exp(psimat%*%lambda0)))
  -log(sum(exp(psimat%*%lambda0)))
}
gr.negkumul.step1 <- function(lambda0,psimat){ # gradient wrt lambda0
  epl <- exp(psimat%*%lambda0)
  return(-crossprod(psimat,epl)/sum(epl))
}
negkumul.step2 <- function(lambda,psimat,pi0){ # (-1)*emp. cumul. gen. function of psi
#   as.numeric(-log(crossprod(pi0,exp(psimat%*%lambda))))
  -log(sum(pi0*exp(psimat%*%lambda)))
}
gr.negkumul.step2 <- function(lambda,psimat,pi0){ # gradient wrt lambda
  epl <- exp(psimat%*%lambda)
  return(as.numeric(-rowSums(t(psimat)%*%(pi0*epl))/crossprod(pi0,epl)))
}
scores.mat.ml <- function(theta,y,designX,offset,minmu,maxmu){ # for esdpt.ml
  mu <- invlink(designX%*%theta[-1]+offset) # mean vector, nothing to do with Lagrange multiplier
  mu[which(mu>maxmu)] <- maxmu
  mu[which(mu<minmu)] <- minmu
  score.sig <- as.numeric(digamma(y+1/theta[1])-digamma(1/theta[1])-log(theta[1]*mu+1)+
                            -theta[1]*(y-mu)/(theta[1]*mu+1)/(-theta[1]^2))
  score.bet <- designX*(as.vector((y-mu)/(1+theta[1]*mu))%x%t(rep(1,dim(designX)[2]))) # ML scores for beta
  return(as.matrix(cbind(score.sig,score.bet))) # returns psimat (nxp)
}
max.lambda0.ml <- function(theta1,theta2,lagrange.ini,y,designX,offset,minmu,maxmu){ # inner max over Lagrange multiplier lambda0, Stage 1
  theta <- c(theta1,theta2)
  psimat <- scores.mat.ml(theta,y,designX,offset,minmu,maxmu) # for fixed theta
  maxi <- optim(par=lagrange.ini,fn=negkumul.step1,gr=gr.negkumul.step1,method='BFGS',control=list(fnscale=-1),psimat=psimat)
  out.maxi <- maxi$value
  attributes(out.maxi) <- list('lambda0'=maxi$par)
  return(out.maxi)
}
max.lambda.ml <- function(theta1,theta2,lagrange.ini,y,designX,offset,pi0,minmu,maxmu){ # inner max over Lagrange multiplier lambda1, Stage 2
  theta <- c(theta1,theta2)
  psimat <- scores.mat.ml(theta,y,designX,offset,minmu,maxmu) # for fixed theta
  maxi <- optim(par=lagrange.ini,fn=negkumul.step2,gr=gr.negkumul.step2,method='BFGS',control=list(fnscale=-1),psimat=psimat,pi0=pi0)
  # out.maxi <- maxi$value
  # attributes(out.maxi) <- list('lambda'=maxi$par)
  # return(out.maxi)
  return(maxi$value)
}
scores.mat.rob <- function(theta,y,designX,offset,c.beta,c.sigma,weights.x,minmu,maxmu){ # for esdpt.rob
  sigma <- theta[1]
  mu <- invlink(designX%*%theta[-1]+offset) # mean vector, nothing to do with Lagrange multiplier
  mu[which(mu>maxmu)] <- maxmu
  mu[which(mu<minmu)] <- minmu
  sqrtVmu <- sqrt(varfunc(mu,sigma))
  res <- (y-mu)/sqrtVmu
  ## robust score for beta
  tukey.res.beta <- ifelse(abs(res)>c.beta,0,((res/c.beta)^2-1)^2*res)
  E.tukey.res.beta <- sapply(X=mu,FUN=expect.tukey.beta,sigma=sigma,c.tukey=c.beta)
  score.beta <- designX*(as.numeric((tukey.res.beta-E.tukey.res.beta)/sqrtVmu*mu*weights.x)%x%t(rep(1,dim(designX)[2])))
  ## robust score for sigma
  E.tukey.res.sigma <- sapply(X=mu,FUN=expect.tukey.sigma,sigma=sigma,c.tukey=c.sigma)
  score.sig.ml <- fullscore.sig(y=y,mui=mu,sigma=sigma) # ML score for sigma
  score.sigma <- (ifelse(abs(res)>c.sigma,0,((res/c.sigma)^2-1)^2)*score.sig.ml-E.tukey.res.sigma)*weights.x
  return(as.matrix(cbind(score.sigma,score.beta))) # returns psimat (nxp)
}
max.lambda0.rob <- function(theta1,theta2,lagrange.ini,y,designX,c.beta,c.sigma,weights.x,offset,minmu,maxmu){ # inner max over Lagrange multiplier lambda0, Stage 1
  theta <- c(theta1,theta2)
  psimat <- scores.mat.rob(theta,y,designX,offset,c.beta,c.sigma,weights.x,minmu,maxmu) # for fixed theta
  maxi <- optim(par=lagrange.ini,fn=negkumul.step1,gr=gr.negkumul.step1,method='BFGS',control=list(fnscale=-1),psimat=psimat)
  out.maxi <- maxi$value
  attributes(out.maxi) <- list('lambda0'=maxi$par)
  return(out.maxi)
}
max.lambda.rob <- function(theta1,theta2,lagrange.ini,y,designX,c.beta,c.sigma,weights.x,offset,pi0,minmu,maxmu){ # inner max over Lagrange multiplier lambda, Stage 2
  theta <- c(theta1,theta2)
  psimat <- scores.mat.rob(theta,y,designX,offset,c.beta,c.sigma,weights.x,minmu,maxmu) # for fixed theta
  maxi <- optim(par=lagrange.ini,fn=negkumul.step2,gr=gr.negkumul.step2,method='BFGS',control=list(fnscale=-1),psimat=psimat,pi0=pi0)
  # out.maxi <- maxi$value
  # attributes(out.maxi) <- list('lambda'=maxi$par)
  # return(out.maxi)
  return(maxi$value)
}



#####################################################
### Support functions, could be good to be documented

nb.glm.ml <- function(y,designX,offset=rep(0,length(y)),minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5){
  #------------------------------------------------------------------------------------------
  # Initialization by Poisson GLM and moment-based estimator for sigma
  #------------------------------------------------------------------------------------------
  n <- length(y)
  lb <- dim(designX)[2] # length(beta)
  wls <- glm(y~designX-1,family='poisson',offset=offset)
  beta <- coef(wls)
  # eta <- designX%*%beta
  eta <- wls$lin # offset handled automatically
  mu <- invlink(eta)
  mu[which(mu>maxmu)] <- maxmu
  mu[which(mu<minmu)] <- minmu
  sigma <- sum((y/mu-1)^2)/n # moment-based estimator, iid approx
  sigma <- sig.estim(y=y,mu=mu,sigma=sigma,minsig=minsig,maxsig=maxsig,tol=tol,maxit=maxit)
  #------------------------------------------------------------------------------------------
  # Iterate between IRWLS for beta and Newton-Raphson for sigma
  #------------------------------------------------------------------------------------------
  full.loglkhd1 <- 0
  full.loglkhd0 <- full.loglkhd1+tol+1
  it <- 0
  while(abs(full.loglkhd1-full.loglkhd0)>tol & it<maxit){
    full.loglkhd0 <- full.loglkhd1
    # mu
    loglkhd.mu1 <- 0
    loglkhd.mu0 <- loglkhd.mu1+tol+1
    it.mu <- 0
    while(abs(loglkhd.mu1-loglkhd.mu0)>tol & it.mu<maxit){
      loglkhd.mu0 <- loglkhd.mu1
      wi <- 1/((derivlink(mu))^2*varfunc(mu,sigma))
      z <- eta+(y-mu)*derivlink(mu)
      wls <- lm(z~designX-1,weights=wi,offset=offset)
      beta <- coef(wls)
      # eta <- designX%*%beta
      eta <- wls$fitted # offset handled automatically
      mu <- invlink(eta)
      mu[which(mu>maxmu)] <- maxmu
      mu[which(mu<minmu)] <- minmu
      loglkhd.mu1 <- loglkhd(y=y,sigma=sigma,mu=mu)
      it.mu <- it.mu+1
    }
    # sigma
    sigma <- sig.estim(y=y,mu=mu,sigma=sigma,minsig=minsig,maxsig=maxsig,tol=tol,maxit=maxit)
    full.loglkhd1 <- loglkhd(y=y,sigma=sigma,mu=mu)
    it <- it+1
  }
  if (is.null(dimnames(designX)[[2]])){
    names.theta <- paste('x',(1:lb)-1,sep='')
  } else {
    names.theta <- unlist(dimnames(designX)[2]) # unlist(names(beta))
  }
  names.theta <- c('sigma','intercept',names.theta[-1])
  theta.est <- c(sigma,beta)
  names(theta.est) <- names.theta
  return(list('coef'=theta.est,'fitted'=as.numeric(mu)))
} # END nb.glm.ml
stdev.nb.glm.ml <- function(beta,sigma,designX,offset,full=FALSE,prec=1e-10){ # prec only for Fisher info of sigma
  lb <- dim(designX)[2] # length(beta)
  if (is.null(dimnames(designX)[[2]])){dimnames(designX)[[2]] <- paste('x',(1:lb)-1,sep='')}
  if (missing(offset)){
    eta <- designX%*%beta
  } else {
    eta <- cbind(designX,offset)%*%c(beta,1)
  }
  fitted.mu <- invlink(eta)
  Wmat <- diag(as.numeric(derivinvlink(eta)^2/varfunc(fitted.mu,sigma)))
  invinfo.beta <- solve(t(designX)%*%Wmat%*%designX)
  if (full){ # full Fisher info, sigma included
    invinfo.sigma <- 1/sum(sapply(X=fitted.mu,FUN=Fisherinfo.sigma,sigma=sigma,prec=prec))
    fullinvinfo <- cbind(c(invinfo.sigma,rep(0,lb)),rbind(rep(0,lb),invinfo.beta)) # orthogonal
    names.x <- unlist(dimnames(fullinvinfo)[2])
    names.x[1:2] <- c('sigma','intercept')
    dimnames(fullinvinfo) <- rep(list(names.x),times=2)
    std.beta <- sqrt(diag(fullinvinfo[-1,-1]))
    std.sigma <- sqrt(fullinvinfo[1,1])
    #     names(std.sigma) <- 'sigma'
    return(list('std.err.beta'=std.beta,'varcovar.beta'=fullinvinfo[-1,-1],
                'std.err.sigma'=std.sigma,'full'=fullinvinfo))
  } else { # only for beta
    names.x <- unlist(dimnames(invinfo.beta)[2])
    names.x[1] <- 'intercept'
    dimnames(invinfo.beta) <- rep(list(names.x),times=2)
    std.beta <- sqrt(diag(invinfo.beta))
    return(list('std.err.beta'=std.beta,'varcovar.beta'=invinfo.beta))
  }
} # END stdev.nb.glm.ml
nb.glm.rob <- function(y,designX,offset=rep(0,length(y)),c.tukey.beta=10,c.tukey.sigma=10,weights.on.x='none',quantile.used=floor(length(y)*0.8),
                       minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5,maxit.sig=30,tol.sig=1e-6,warn=FALSE){
  n <- length(y)
  lb <- dim(designX)[2] # length(beta)
  onevec <- rep(1,n)
  #-------------------------------------------------------------------
  # MLEs of both sigma and beta
  #-------------------------------------------------------------------
  theta.mle <- nb.glm.ml(y=y,designX=designX,offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  sigma <- theta.mle$coef[1]
  mu <- theta.mle$fitted
  eta <- link(mu)
  update.sigma <- T # at least 1 iteration of robust est, worst case = does not move from minsig/maxsig
  #-------------------------------------------------------------------
  # Weights on design
  #-------------------------------------------------------------------
  if (weights.on.x=='none'){
    weights.x <- onevec
  } else {
    if (dim(designX)[2]==1){ # cannot compute weights on design if only an intercept
      weights.x <- onevec
    } else {
      notfullX <- designX[,-1]
      if (weights.on.x=='hat'){
        weights.x <- sqrt(1-diag(notfullX%*%solve(t(notfullX)%*%notfullX)%*%t(notfullX)))
      } else if (weights.on.x=='robCov'){
        Xrc <- cov.rob(notfullX,quantile.used=quantile.used)
        D2 <- mahalanobis(notfullX,center=Xrc$center,cov=Xrc$cov) # copied from robustbase:::wts_RobDist
        weights.x <- 1/sqrt(1+pmax.int(0,8*(D2-dim(notfullX)[2])/sqrt(2*dim(notfullX)[2]))) # from Heritier et al. (2009), p.138
      } else if (weights.on.x=='hard'){
        Xrc <- cov.rob(notfullX,quantile.used=quantile.used)
        D2 <- mahalanobis(notfullX,center=Xrc$center,cov=Xrc$cov) # copied from robustbase:::wts_RobDist
        qchi2 <- qchisq(p=0.95,df=dim(notfullX)[2])
        weights.x <- ifelse(D2<=qchi2,1,0)
      } else {stop('Only "hard", "robCov" and "hat" are implemented for weights.on.x.')}
    }
  }
  #-------------------------------------------------------------------
  # Robust estimates of both sigma and beta
  #-------------------------------------------------------------------
  sigma0 <- sigma+tol+1
  beta11 <- 0
  beta00 <- beta11+tol+1
  it <- 0
  while(abs(sigma-sigma0)>tol | max(abs(beta11-beta00))>tol & it<maxit){
    sigma0 <- sigma
    beta00 <- beta11
    # estimate sigma given mu
    if (update.sigma){
      tryit <- try(uniroot(f=sig.rob.tukey,interval=c(minsig,maxsig),tol=tol.sig,maxiter=maxit.sig,mu=mu,y=y,c.tukey=c.tukey.sigma,weights.x=weights.x),T)
      if (class(tryit)=='try-error'){
        if (warn){message(paste('warning: robust update of sigma failed at iteration ',it,', returning last value',sep=''))}
        update.sigma <- FALSE
      } else {
        sigma <- tryit$root
        if (sigma>maxsig){sigma <- maxsig}
        if (sigma<minsig){ # unlikely with interval=c(minsig,maxsig) in uniroot
          update.sigma <- FALSE
        }
      }
    }
    # estimate mu given sigma
    beta1 <- 0
    beta0 <- beta1+tol+1
    it.mu <- 0
    while(max(abs(beta1-beta0))>tol & it.mu<maxit){
      beta0 <- beta1
      bi <- sapply(X=mu,FUN=E.tukeypsi.2,sigma=sigma,c.tukey=c.tukey.beta)*varfunc(mu,sigma)^(-3/2)*derivinvlink(eta)^2*weights.x
      ei <- (tukeypsi(r=(y-mu)/sqrt(varfunc(mu,sigma)),c.tukey=c.tukey.beta)-sapply(X=mu,FUN=E.tukeypsi.1,sigma=sigma,c.tukey=c.tukey.beta))/
        sapply(X=mu,FUN=E.tukeypsi.2,sigma=sigma,c.tukey=c.tukey.beta)*varfunc(mu,sigma)*derivlink(mu)
      zi <- eta + ei
      wls <- lm(zi~designX-1,weights=bi,offset=offset)
      beta1 <- coef(wls)
      eta <- wls$fitted # offset handled automatically
      mu <- invlink(eta)
      mu[which(mu>maxmu)] <- maxmu
      mu[which(mu<minmu)] <- minmu
      it.mu <- it.mu+1
    }
    beta11 <- beta1
    it <- it+1
  }
  if (is.null(dimnames(designX)[[2]])){
    names.theta <- paste('x',(1:lb)-1,sep='')
  } else {
    names.theta <- unlist(dimnames(designX)[[2]]) # unlist(names(beta11))
  }
  names.theta <- c('sigma','intercept',names.theta[-1])
  theta.est <- c(sigma,beta11)
  names(theta.est) <- names.theta
  resid <- (y-mu)/sqrt(varfunc(mu,sigma))
  weights.y <- as.numeric(ifelse(resid==0,1,tukeypsi(r=resid,c.tukey=c.tukey.beta)/resid))
  return(list('coef'=theta.est,'weights.y'=weights.y,'weights.x'=weights.x,
              'residuals.Pearson'=resid,'fitted'=mu))
} # END nb.glm.rob
stdev.nb.glm.rob <- function(designX,beta,sigma,c.tukey.beta,c.tukey.sigma,offset,weights.x){
  lb <- dim(designX)[2] # length(beta)
  if (is.null(dimnames(designX)[[2]])){dimnames(designX)[[2]] <- paste('x',(1:lb)-1,sep='')}
  n <- dim(designX)[1]
  onevec <- rep(1,n)
  if (missing(offset)){
    eta <- designX%*%beta
    mu <- invlink(eta)
  } else {
    eta <- cbind(designX,offset)%*%c(beta,1)
    mu <- invlink(eta)
  }
  if (missing(weights.x)){weights.x <- onevec} # otherwise supplied from nb.glm.rob
  ## evaluate all expectations at each mui
  expect <- sapply(X=mu,FUN=all.expectations.tukey,sigma=sigma,c.tukey.beta=c.tukey.beta,c.tukey.sigma=c.tukey.sigma)
  ## compute all blocks of M and Q
  M22 <- t(designX)%*%diag(as.numeric(unlist(expect['tukeypsi2',])*derivinvlink(eta)^2*weights.x))%*%designX/n
  M12 <- as.numeric(t(designX)%*%(unlist(expect['psibetascoresig.beta',])*derivinvlink(eta)*weights.x))/n
  M21 <- M12 # M is symmetric here because Tukey's biweight used for both sigma and beta
  M11 <- t(weights.x)%*%unlist(expect['psiscoresig2',])/n
  Q22 <- t(designX)%*%diag(as.numeric(unlist(expect['tukeypsi13',])*(derivinvlink(eta)*weights.x)^2))%*%designX/n
  Q21 <- as.numeric(t(designX)%*%(unlist(expect['psibetaminuspsisig',])*derivinvlink(eta)*weights.x^2))/n
  Q12 <- Q21 # Q is always symmetric
  Q11 <- t(weights.x^2)%*%unlist(expect['psiscoresig13',])/n
  ## stdev from diag of full sandwich M^(-1)*Q*M^(-T)
  fullM <- rbind(t(c(M11,M12)),cbind(M21,M22))
  fullQ <- rbind(t(c(Q11,Q12)),cbind(Q21,Q22))
  names.x <- unlist(dimnames(fullM)[2])
  names.x[1:2] <- c('sigma','intercept')
  fullMQM <- solve(fullM)%*%fullQ%*%solve(fullM)
  dimnames(fullM) <- rep(list(names.x),times=2)
  dimnames(fullQ) <- rep(list(names.x),times=2)
  dimnames(fullMQM) <- rep(list(names.x),times=2)
  stdev <- sqrt(diag(fullMQM/n))
  return(list('std.err.beta'=stdev[-1],'std.err.sigma'=stdev[1],'fullMQM'=fullMQM,
              'M'=fullM,'Q'=fullQ))
} # END stdev.nb.glm.rob


##########################################
### User-level functions, to be documented

wt.ml <- function(y,designX,d=1,offset,minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  #------------------------------------------------------------------------------------------
  # Eval and output
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.ml(y=y,designX=designX,offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  theta.1 <- fullfit$coef
  var.beta <- stdev.nb.glm.ml(beta=theta.1[-1],sigma=theta.1[1],designX=designX,offset=offset,full=F)
  wt.val <- as.numeric(t(theta.1[to.test+1])%*%solve(var.beta$varcovar[to.test,to.test])%*%theta.1[to.test+1])
  return(list('value'=wt.val,'coef'=theta.1,'std.err.beta'=var.beta$std.err.beta))
} # END wt.ml
wt.rob <- function(y,designX,d=1,c.beta=10,c.sigma=10,offset,weights.on.x='none',quantile.used=floor(length(y)*0.8),warn=FALSE,
                   minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5,maxit.sig=30,tol.sig=1e-6){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  #------------------------------------------------------------------------------------------
  # Eval and output
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.rob(y=y,designX=designX,c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,offset=offset,weights.on.x=weights.on.x,quantile.used=quantile.used,
                        minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,maxit.sig=maxit.sig,tol.sig=tol.sig,warn=warn)
  theta.1 <- fullfit$coef
  var.theta <- stdev.nb.glm.rob(designX=designX,beta=theta.1[-1],sigma=theta.1[1],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,weights.x=fullfit$weights.x,offset=offset)
  wt.val <- as.numeric(n*t(theta.1[to.test+1])%*%solve(var.theta$fullMQM[to.test+1,to.test+1])%*%theta.1[to.test+1])
  return(list('value'=wt.val,'coef'=theta.1,'std.err.beta'=var.theta$std.err.beta,'weights.y'=fullfit$weights.y,'weights.x'=fullfit$weights.x))
} # END wt.rob
st.ml <- function(y,designX,d=1,offset,minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  #------------------------------------------------------------------------------------------
  # Eval and output
  #------------------------------------------------------------------------------------------
  mlfit.0 <- nb.glm.ml(y=y,designX=designX[,-to.test],minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,offset=offset)
  if (any(mlfit.0$fitted==maxmu)){stop('ML fit gave unusually large fitted values.')}
  theta.0 <- c(mlfit.0$coef,rep(0,d))
  fullinfo <- stdev.nb.glm.ml(beta=theta.0[-1],sigma=theta.0[1],designX=designX,offset=offset,full=T)$full
  scorevec <- scores.ml(theta=theta.0,y=y,designX=designX,minmu=minmu,maxmu=maxmu,offset=offset)
  var.theta.0 <- stdev.nb.glm.ml(beta=mlfit.0$coef[-1],sigma=mlfit.0$coef[1],designX=designX[,-to.test],offset=offset,full=F)
  names.x <- unlist(dimnames(fullinfo)[2])
  names.x[1:2] <- c('sigma','intercept')
  dimnames(fullinfo) <- rep(list(names.x),times=2)
  std.beta <- var.theta.0$std.err.beta
  return(list('value'=as.numeric(t(scorevec)%*%fullinfo%*%scorevec),'coef'=theta.0,'std.err.beta'=std.beta))
} # END st.ml
st.rob <- function(y,designX,d=1,c.beta=10,c.sigma=10,offset,weights.on.x='none',quantile.used=floor(length(y)*0.8),warn=FALSE,
                   minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5,maxit.sig=30,tol.sig=1e-6){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  #------------------------------------------------------------------------------------------
  # Eval and output
  #------------------------------------------------------------------------------------------
  emptyfit <- nb.glm.rob(y=y,designX=designX[,-to.test],
                         c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,
                         offset=offset,weights.on.x=weights.on.x,
                         quantile.used=quantile.used,
                         minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,
                         maxit=maxit,tol=tol,maxit.sig=maxit.sig,
                         tol.sig=tol.sig,warn=warn)
  if (any(emptyfit$fitted==maxmu)){stop('Rob fit gave unusually large fitted values.')}
  theta.0 <- c(emptyfit$coef,rep(0,d))
  scorevec <- scores.rob(theta=theta.0,y=y,designX=designX,offset=offset,
                         c.beta=c.beta,c.sigma=c.sigma,
                         weights.x=emptyfit$weights.x,minmu=minmu,maxmu=maxmu)
  sandlist <- stdev.nb.glm.rob(designX=designX,beta=theta.0[-1],sigma=theta.0[1],
                               c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,
                               weights.x=emptyfit$weights.x,offset=offset)
  M221 <- sandlist$M[to.test+1,to.test+1]-
    sandlist$M[to.test+1,-(to.test+1)]%*%
    solve(sandlist$M[-(to.test+1),-(to.test+1)])%*%
    sandlist$M[-(to.test+1),to.test+1] # Schur complement
  Cmat <- M221%*%sandlist$fullMQM[to.test+1,to.test+1]%*%t(M221)
  statval <- t(scorevec[to.test+1])%*%solve(Cmat)%*%scorevec[to.test+1]/n
  var.theta.0 <- stdev.nb.glm.rob(designX=designX[,-to.test],
                                  beta=emptyfit$coef[-1],sigma=emptyfit$coef[1],
                                  c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,
                                  weights.x=emptyfit$weights.x,offset=offset)
  return(list('value'=as.numeric(statval),'coef'=theta.0,
              'std.err.beta'=var.theta.0$std.err.beta,
              'weights.y'=emptyfit$weights.y,'weights.x'=emptyfit$weights.x))
} # END st.rob
lrt.ml <- function(y,designX,d=1,offset,minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  #------------------------------------------------------------------------------------------
  # Eval and output
  #------------------------------------------------------------------------------------------
  mlfit.1 <- nb.glm.ml(y=y,designX=designX,offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  mlfit.0 <- nb.glm.ml(y=y,designX=designX[,-to.test],offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  var.beta.1 <- stdev.nb.glm.ml(beta=mlfit.1$coef[-1],sigma=mlfit.1$coef[1],designX=designX,offset=offset,full=F)
  var.beta.0 <- stdev.nb.glm.ml(beta=mlfit.0$coef[-1],sigma=mlfit.0$coef[1],designX=designX[,-to.test],offset=offset,full=F)
  lrt.val <- 2*(loglkhd(sigma=mlfit.1$coef[1],y=y,mu=mlfit.1$fitted)-loglkhd(sigma=mlfit.0$coef[1],y=y,mu=mlfit.0$fitted))
  return(list('value'=as.numeric(lrt.val),'coef.H1'=mlfit.1$coef,'std.err.beta.H1'=var.beta.1$std.err.beta,
              'coef.H0'=c(mlfit.0$coef,rep(0,d)),'std.err.beta.H0'=var.beta.0$std.err.beta))
} # END lrt.ml
sdpt.ml <- function(y,designX,d=1,offset,minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5,prec=1e-10){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  range.beta <- c(-100,100)
  lagrange.range <- c(-100,100)
  lagrange.ini <- rep(0,lb+1) # starting values
  list.designX <- as.list(as.data.frame(t(designX))) # for applying score.class.i
  #------------------------------------------------------------------------------------------
  # Unconstr. and constr. estim. of theta=c(theta1,theta2)
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.ml(y=y,designX=designX,offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  emptyfit <- nb.glm.ml(y=y,designX=designX[,-to.test],offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  var.beta.1 <- stdev.nb.glm.ml(beta=fullfit$coef[-1],sigma=fullfit$coef[1],designX=designX,offset=offset,full=F)
  var.beta.0 <- stdev.nb.glm.ml(beta=emptyfit$coef[-1],sigma=emptyfit$coef[1],designX=designX[,-to.test],offset=offset,full=F)
  theta1.1 <- fullfit$coef[-(to.test+1)]
  theta2.1 <- fullfit$coef[to.test+1]
  theta.0 <- c(emptyfit$coef,rep(0,d))
  invsig.0 <- 1/emptyfit$coef[1]
  mu.0 <- emptyfit$fitted
  maxj <- as.numeric(qnbinom(p=prec,mu=mu.0,size=invsig.0,lower.tail=F))
  pNB <- mapply(FUN=function(j,mu){dnbinom(x=0:j,mu=mu,size=invsig.0)},j=maxj,mu=mu.0) # pNB is a list of length=n
  #------------------------------------------------------------------------------------------
  # Eval test stat and output
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=maxi.lambda.ml,theta2.1=theta2.1,pNB=pNB,maxj=maxj,lagrange.ini=lagrange.ini,
                 designX=designX,list.designX=list.designX,prec=prec,lagrange.range=lagrange.range,offset=offset,
                 lower=c(minsig,rep(range.beta[1],lb-d)),minmu=minmu,maxmu=maxmu,
                 upper=c(maxsig,rep(range.beta[2],lb-d)))
  return(list('value'=2*n*mini$objective,'coef.H1'=fullfit$coef,'std.err.beta.H1'=var.beta.1$std.err.beta,#'coef.conv'=mini$par,
              'coef.H0'=theta.0,'std.err.beta.H0'=var.beta.0$std.err.beta))
} # END sdpt.ml
sdpt.rob <- function(y,designX,d=1,c.beta=10,c.sigma=10,offset,weights.on.x='none',quantile.used=floor(length(y)*0.8),warn=FALSE,
                     minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5,maxit.sig=30,tol.sig=1e-6,prec=1e-10){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  range.beta <- c(-100,100)
  lagrange.range <- c(-100,100)
  lagrange.ini <- rep(0,lb+1) # starting values
  list.designX <- as.list(as.data.frame(t(designX))) # for applying score.class.i
  #------------------------------------------------------------------------------------------
  # Unconstr. and constr. estim. of theta=c(theta1,theta2)
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.rob(y=y,designX=designX,c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,offset=offset,weights.on.x=weights.on.x,quantile.used=quantile.used,
                        minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,maxit.sig=maxit.sig,tol.sig=tol.sig,warn=warn)
  emptyfit <- nb.glm.rob(y=y,designX=designX[,-to.test],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,offset=offset,weights.on.x=weights.on.x,quantile.used=quantile.used,
                         minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,maxit.sig=maxit.sig,tol.sig=tol.sig,warn=warn)
  var.beta.1 <- stdev.nb.glm.rob(designX=designX,beta=fullfit$coef[-1],sigma=fullfit$coef[1],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,weights.x=fullfit$weights.x,offset=offset)
  var.beta.0 <- stdev.nb.glm.rob(designX=designX[,-to.test],beta=emptyfit$coef[-1],sigma=emptyfit$coef[1],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,weights.x=emptyfit$weights.x,offset=offset)
  theta1.1 <- fullfit$coef[-(to.test+1)]
  theta2.1 <- fullfit$coef[(to.test+1)]
  theta.0 <- c(emptyfit$coef,rep(0,d))
  invsig.0 <- 1/theta.0[1]
  mu.0 <- invlink(designX%*%theta.0[-1]+offset)
  mu.0[which(mu.0>maxmu)] <- maxmu
  mu.0[which(mu.0<minmu)] <- minmu
  maxj <- as.numeric(qnbinom(p=prec,mu=mu.0,size=invsig.0,lower.tail=F))
  pNB <- mapply(FUN=function(j,mu){dnbinom(x=0:j,mu=mu,size=invsig.0)},j=maxj,mu=mu.0) # pNB is a list of length=n
  #------------------------------------------------------------------------------------------
  # Eval test stat and output
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=maxi.lambda.rob,theta2.1=theta2.1,pNB=pNB,maxj=maxj,lagrange.ini=lagrange.ini,offset=offset,
                 designX=designX,list.designX=list.designX,prec=prec,lagrange.range=lagrange.range,c.beta=c.beta,c.sigma=c.sigma,
                 lower=c(minsig,rep(range.beta[1],lb-d)),minmu=minmu,maxmu=maxmu,weights.x=fullfit$weights.x,
                 upper=c(maxsig,rep(range.beta[2],lb-d)))
  return(list('value'=2*n*mini$objective,'coef.H1'=fullfit$coef,'std.err.beta.H1'=var.beta.1$std.err.beta,#'coef.conv'=mini$par,'weights.y.H0'=emptyfit$weights.y,
              'coef.H0'=theta.0,'std.err.beta.H0'=var.beta.0$std.err.beta,'weights.y'=fullfit$weights.y,'weights.x'=fullfit$weights.x
              ))
} # END sdpt.rob
esdpt.ml <- function(y,designX,d=1,offset,minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  range.beta <- c(-100,100)
  lagrange.ini <- rep(0,lb+1) # starting values
  #------------------------------------------------------------------------------------------
  # Stage 0: constr. and unconstr. estim. of theta=c(theta1,theta2)
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.ml(y=y,designX=designX,offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  emptyfit <- nb.glm.ml(y=y,designX=designX[,-to.test],offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  var.beta.1 <- stdev.nb.glm.ml(beta=fullfit$coef[-1],sigma=fullfit$coef[1],designX=designX,offset=offset,full=F)
  var.beta.0 <- stdev.nb.glm.ml(beta=emptyfit$coef[-1],sigma=emptyfit$coef[1],designX=designX[,-to.test],offset=offset,full=F)
  theta1.1 <- fullfit$coef[-(to.test+1)]
  theta2.1 <- fullfit$coef[to.test+1]
  theta1.0 <- emptyfit$coef
  theta2.0 <- rep(0,d) # value assumed under H0
  #------------------------------------------------------------------------------------------
  # Stage 1: ET estim. of theta1 under H0 constraint on theta2 => weights under H0
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=max.lambda0.ml,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,
                 lower=c(minsig,rep(range.beta[1],lb-d)),minmu=minmu,maxmu=maxmu,
                 upper=c(maxsig,rep(range.beta[2],lb-d)))
  theta1.0 <- mini$par # ET estimator of theta1, constrained under H0
  lambda.0 <- attr(max.lambda0.ml(theta1=theta1.0,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,minmu=minmu,maxmu=maxmu),'lambda0')
  psimat.0 <- scores.mat.ml(theta=c(theta1.0,theta2.0),y=y,designX=designX,offset=offset,minmu=minmu,maxmu=maxmu)
  pi.0 <- exp(psimat.0%*%lambda.0)
  pi.0 <- pi.0/sum(pi.0) # weights under H0 kept fixed
  #------------------------------------------------------------------------------------------
  # Stage 2: ET estim. of theta1 given unconstr. theta2 with fixed weights from Stage 1
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=max.lambda.ml,theta2=theta2.1,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,
                 lower=c(minsig,rep(range.beta[1],lb-d)),pi0=pi.0,minmu=minmu,maxmu=maxmu,
                 upper=c(maxsig,rep(range.beta[2],lb-d))) # mini$par = ET estimator of theta1, unconstrained but involving pi.0
  #------------------------------------------------------------------------------------------
  # Output
  #------------------------------------------------------------------------------------------
  return(list('value'=2*n*mini$objective,'coef.H1'=fullfit$coef,'std.err.beta.H1'=var.beta.1$std.err.beta,#'lambda0'=lambda.0,
              'coef.H0'=c(emptyfit$coef,theta2.0),'std.err.beta.H0'=var.beta.0$std.err.beta#,'coef.ET.H0'=c(theta1.0,theta2.0),'coef.ET.H1'=c(mini$par,theta2.1)
  ))
} # END esdpt.ml
esdpt.rob <- function(y,designX,d=1,c.beta=10,c.sigma=10,offset,weights.on.x='none',quantile.used=floor(length(y)*0.8),warn=FALSE,
                      minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5,maxit.sig=30,tol.sig=1e-6){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  range.beta <- c(-100,100)
  lagrange.ini <- rep(0,lb+1) # starting values
  #------------------------------------------------------------------------------------------
  # Stage 0: constr. and unconstr. estim. of theta=c(theta1,theta2)
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.rob(y=y,designX=designX,c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,offset=offset,weights.on.x=weights.on.x,quantile.used=quantile.used,
                        minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,maxit.sig=maxit.sig,tol.sig=tol.sig,warn=warn)
  emptyfit <- nb.glm.rob(y=y,designX=designX[,-to.test],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,offset=offset,weights.on.x=weights.on.x,quantile.used=quantile.used,
                         minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,maxit.sig=maxit.sig,tol.sig=tol.sig,warn=warn)
  var.beta.1 <- stdev.nb.glm.rob(designX=designX,beta=fullfit$coef[-1],sigma=fullfit$coef[1],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,weights.x=fullfit$weights.x,offset=offset)
  var.beta.0 <- stdev.nb.glm.rob(designX=designX[,-to.test],beta=emptyfit$coef[-1],sigma=emptyfit$coef[1],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,weights.x=emptyfit$weights.x,offset=offset)
  theta1.1 <- fullfit$coef[-(to.test+1)]
  theta2.1 <- fullfit$coef[(to.test+1)]
  theta1.0 <- emptyfit$coef
  theta2.0 <- rep(0,d) # value assumed under H0
  #------------------------------------------------------------------------------------------
  # Stage 1: ET estim. of theta1 under H0 constraint on theta2 => weights under H0
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=max.lambda0.rob,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,
                 lower=c(minsig,rep(range.beta[1],lb-d)),minmu=minmu,maxmu=maxmu,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,
                 upper=c(maxsig,rep(range.beta[2],lb-d)))
  #   mini <- optim(par=theta1.1,fn=max.lambda0.rob,method='BFGS',theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,
  #                 minmu=minmu,maxmu=maxmu,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,
  #                 )
  theta1.0 <- mini$par  # ET estimator of theta1, constrained under H0
  lambda.0 <- attr(max.lambda0.rob(theta1=theta1.0,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,offset=offset,minmu=minmu,maxmu=maxmu),'lambda0')
  psimat.0 <- scores.mat.rob(theta=c(theta1.0,theta2.0),y=y,designX=designX,offset=offset,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,minmu=minmu,maxmu=maxmu)
  pi.0 <- exp(psimat.0%*%lambda.0)
  pi.0 <- pi.0/sum(pi.0) # weights under H0 kept fixed
  #------------------------------------------------------------------------------------------
  # Stage 2: ET estim. of theta1 given unconst. theta2 with fixed weights from Stage 1
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=max.lambda.rob,theta2=theta2.1,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,pi0=pi.0,
                 lower=c(minsig,rep(range.beta[1],lb-d)),minmu=minmu,maxmu=maxmu,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,
                 upper=c(maxsig,rep(range.beta[2],lb-d))) # mini$par = ET estimator of theta1, unconstrained but involving pi.0
  #   mini <- optim(par=theta1.1,fn=max.lambda.rob,method='BFGS',theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,pi0=pi.0,
  #                 minmu=minmu,maxmu=maxmu,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,
  #                 ) # mini$par = ET estimator of theta1, unconstrained but involving pi.0
  #------------------------------------------------------------------------------------------
  # Output
  #------------------------------------------------------------------------------------------
  return(list('value'=2*n*mini$objective,'coef.H1'=fullfit$coef,'std.err.beta.H1'=var.beta.1$std.err.beta, # 2*n*mini$value
              'coef.H0'=c(emptyfit$coef,theta2.0),'std.err.beta.H0'=var.beta.0$std.err.beta,#'weights.y.H0'=emptyfit$weights.y,
              'weights.y'=fullfit$weights.y,'weights.x'=fullfit$weights.x#,'coef.ET.H0'=c(theta1.0,theta2.0),'coef.ET.H1'=c(mini$par,theta2.1)
  ))
} # END esdpt.rob
tett.ml <- function(y,designX,d=1,offset,minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  range.beta <- c(-100,100)
  lagrange.ini <- rep(0,lb+1) # starting values
  #------------------------------------------------------------------------------------------
  # Stage 0: constr. and unconstr. estim. of theta=c(theta1,theta2)
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.ml(y=y,designX=designX,offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  emptyfit <- nb.glm.ml(y=y,designX=designX[,-to.test],offset=offset,minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol)
  var.beta.1 <- stdev.nb.glm.ml(beta=fullfit$coef[-1],sigma=fullfit$coef[1],designX=designX,offset=offset,full=F)
  var.beta.0 <- stdev.nb.glm.ml(beta=emptyfit$coef[-1],sigma=emptyfit$coef[1],designX=designX[,-to.test],offset=offset,full=F)
  theta1.1 <- fullfit$coef[-(to.test+1)]
  theta2.1 <- fullfit$coef[to.test+1]
  theta1.0 <- emptyfit$coef
  theta2.0 <- rep(0,d) # value assumed under H0
  #------------------------------------------------------------------------------------------
  # Stage 1: ET estim. of theta1 under H0 constraint on theta2 => weights under H0
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=max.lambda0.ml,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,
                 lower=c(minsig,rep(range.beta[1],lb-d)),minmu=minmu,maxmu=maxmu,
                 upper=c(maxsig,rep(range.beta[2],lb-d)))
  theta1.0 <- mini$par # ET estimator of theta1, constrained under H0
  lambda.0 <- attr(max.lambda0.ml(theta1=theta1.0,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,minmu=minmu,maxmu=maxmu),'lambda0')
  psimat.0 <- scores.mat.ml(theta=c(theta1.0,theta2.0),y=y,designX=designX,offset=offset,minmu=minmu,maxmu=maxmu)
  #------------------------------------------------------------------------------------------
  # Output
  #------------------------------------------------------------------------------------------
  return(list('value'=2*n*log(sum(exp(2*psimat.0%*%lambda.0))/sum(exp(psimat.0%*%lambda.0))),
              'coef.H1'=fullfit$coef,'std.err.beta.H1'=var.beta.1$std.err.beta,
              'coef.H0'=c(emptyfit$coef,theta2.0),'std.err.beta.H0'=var.beta.0$std.err.beta
  ))
} # END tett.ml
tett.rob <- function(y,designX,d=1,c.beta=10,c.sigma=10,offset,weights.on.x='none',quantile.used=floor(length(y)*0.8),warn=FALSE,
                      minsig=1e-3,maxsig=50,minmu=1e-10,maxmu=1e20,maxit=50,tol=1e-5,maxit.sig=30,tol.sig=1e-6){
  #------------------------------------------------------------------------------------------
  # Set up
  #------------------------------------------------------------------------------------------
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  lb <- dim(designX)[2] # length(beta) including intercept
  if (d>=lb){stop('Composite hypothesis only: dimension of subvector to test at most equals dimenion of beta - 1.')}
  to.test <- lb:(lb-d+1) # indices of coef of beta to test against 0
  if (missing(offset)){offset <- rep(0,n)}
  range.beta <- c(-100,100)
  lagrange.ini <- rep(0,lb+1) # starting values
  #------------------------------------------------------------------------------------------
  # Stage 0: constr. and unconstr. estim. of theta=c(theta1,theta2)
  #------------------------------------------------------------------------------------------
  fullfit <- nb.glm.rob(y=y,designX=designX,c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,offset=offset,weights.on.x=weights.on.x,quantile.used=quantile.used,
                        minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,maxit.sig=maxit.sig,tol.sig=tol.sig,warn=warn)
  emptyfit <- nb.glm.rob(y=y,designX=designX[,-to.test],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,offset=offset,weights.on.x=weights.on.x,quantile.used=quantile.used,
                         minsig=minsig,maxsig=maxsig,minmu=minmu,maxmu=maxmu,maxit=maxit,tol=tol,maxit.sig=maxit.sig,tol.sig=tol.sig,warn=warn)
  var.beta.1 <- stdev.nb.glm.rob(designX=designX,beta=fullfit$coef[-1],sigma=fullfit$coef[1],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,weights.x=fullfit$weights.x,offset=offset)
  var.beta.0 <- stdev.nb.glm.rob(designX=designX[,-to.test],beta=emptyfit$coef[-1],sigma=emptyfit$coef[1],c.tukey.beta=c.beta,c.tukey.sigma=c.sigma,weights.x=emptyfit$weights.x,offset=offset)
  theta1.1 <- fullfit$coef[-(to.test+1)]
  theta2.1 <- fullfit$coef[(to.test+1)]
  theta1.0 <- emptyfit$coef
  theta2.0 <- rep(0,d) # value assumed under H0
  #------------------------------------------------------------------------------------------
  # Stage 1: ET estim. of theta1 under H0 constraint on theta2 => weights under H0
  #------------------------------------------------------------------------------------------
  mini <- nlminb(start=theta1.1,objective=max.lambda0.rob,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,
                 lower=c(minsig,rep(range.beta[1],lb-d)),minmu=minmu,maxmu=maxmu,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,
                 upper=c(maxsig,rep(range.beta[2],lb-d)))
  #   mini <- optim(par=theta1.1,fn=max.lambda0.rob,method='BFGS',theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,offset=offset,
  #                 minmu=minmu,maxmu=maxmu,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,
  #                 )
  theta1.0 <- mini$par  # ET estimator of theta1, constrained under H0
  lambda.0 <- attr(max.lambda0.rob(theta1=theta1.0,theta2=theta2.0,lagrange.ini=lagrange.ini,y=y,designX=designX,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,offset=offset,minmu=minmu,maxmu=maxmu),'lambda0')
  psimat.0 <- scores.mat.rob(theta=c(theta1.0,theta2.0),y=y,designX=designX,offset=offset,c.beta=c.beta,c.sigma=c.sigma,weights.x=fullfit$weights.x,minmu=minmu,maxmu=maxmu)
  #------------------------------------------------------------------------------------------
  # Output
  #------------------------------------------------------------------------------------------
  return(list('value'=2*n*log(sum(exp(2*psimat.0%*%lambda.0))/sum(exp(psimat.0%*%lambda.0))),
              'coef.H1'=fullfit$coef,'std.err.beta.H1'=var.beta.1$std.err.beta, # 2*n*mini$value
              'coef.H0'=c(emptyfit$coef,theta2.0),'std.err.beta.H0'=var.beta.0$std.err.beta,#'weights.y.H0'=emptyfit$weights.y,
              'weights.y'=fullfit$weights.y,'weights.x'=fullfit$weights.x#,'coef.ET.H0'=c(theta1.0,theta2.0),'coef.ET.H1'=c(mini$par,theta2.1)
  ))
} # END tett.rob



